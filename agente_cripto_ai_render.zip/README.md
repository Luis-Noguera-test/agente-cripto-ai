# Agente Cripto AI (Render, 24/7)

Escanea BTC/ETH/SOL/XRP cada 60s (Binance), detecta señales (SMA6>SMA70 + pullback + volumen), gestiona SL/TP, envía alertas al canal (vía Make) y publica un informe 4h con titulares (CoinDesk, The Block, FT) y Fear & Greed.
